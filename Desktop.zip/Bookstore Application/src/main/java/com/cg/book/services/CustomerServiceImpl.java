package com.cg.book.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.book.beans.Customer;
import com.cg.book.dao.CustomerDAO;
import com.cg.book.exception.CustomerDetailsNotFoundException;
@Component("customerServices")
public class CustomerServiceImpl implements CustomerService{

	
	@Autowired
	CustomerDAO customerRepo;
	
	@Override
	public Customer createCustomer(Customer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
	}

	@Override
	public Customer getCustomer(int id) throws CustomerDetailsNotFoundException {
		return customerRepo.findById((long) id).orElseThrow(()-> new 
				CustomerDetailsNotFoundException("Customer Details Not Found"));
	}

	@Override
	public boolean deleteCustomer(int id) throws CustomerDetailsNotFoundException {
		customerRepo.deleteById((long) id);
		return false;
	}

	@Override
	public Customer updateCustomer(int id, Customer customer) throws CustomerDetailsNotFoundException {
		customerRepo.findById((long) id).orElseThrow(()-> new CustomerDetailsNotFoundException("Customer details not found"));	
		return customerRepo.save(customer);
	}

}
