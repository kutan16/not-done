package com.cg.book.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.book.beans.Customer;
import com.cg.book.exception.CustomerDetailsNotFoundException;

public interface CustomerService {

	
	Customer createCustomer(Customer customer);
	Customer getCustomer(int id)throws CustomerDetailsNotFoundException;
	List<Customer> getAllCustomer()throws CustomerDetailsNotFoundException;
	boolean deleteCustomer(int id)throws CustomerDetailsNotFoundException;
	Customer updateCustomer(int id,Customer customer)throws CustomerDetailsNotFoundException;
	
}
