export class Customer {
    
    id: number;
    emailId: string;
    name: string;
    phoneNo: string;
    password: string;
    // confirmPassword: string;
    address: string;
    city: string;
    country: string;
    zipCode: string;
}