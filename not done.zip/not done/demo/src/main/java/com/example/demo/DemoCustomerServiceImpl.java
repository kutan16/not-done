package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("customerServices")
public class DemoCustomerServiceImpl implements DemoCustomerService{

	
	@Autowired
	CustomerRepo customerRepo;
	
	@Override
	public DemoCustomer createCustomer(DemoCustomer customer) {
		return customerRepo.save(customer);
	}

	@Override
	public List<DemoCustomer> getAllCustomer() {
		return customerRepo.findAll();
	}

}
