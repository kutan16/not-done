package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

public interface DemoCustomerService {

	
	DemoCustomer createCustomer(DemoCustomer customer);
	List<DemoCustomer> getAllCustomer();
}
